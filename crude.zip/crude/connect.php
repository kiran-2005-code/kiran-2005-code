<?php

$host='localhost';
$user='root';
$pass='';
$dbname='crude operations';
$conn=mysqli_connect($host,$user,$pass,$dbname);
if(!$conn){
    die('could not connect:'.mysqli_error());
}
echo '';
?>
