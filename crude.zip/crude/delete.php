<?php

include 'user.php';
if(isset($_GET['deleted'])){
    $id=$_GET['deleted'];

    $sql='delete from crud where id=$id';
    $result=mysqli_query($conn,$sql);
    if($result){
        header("location:display.php");
    }
    else{
        die(mysqli_error($conn));
    }
}
?>